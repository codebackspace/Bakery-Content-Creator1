import React from 'react';
import { Link } from 'react-router-dom';
import { Coffee, Instagram, Facebook, Twitter, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-coffee-dark text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div className="flex flex-col">
            <div className="flex items-center mb-4">
              <Coffee className="h-8 w-8 text-accent-gold" />
              <span className="ml-2 text-xl font-serif font-bold uppercase">Abdur rahim khan store</span>
            </div>
            <p className="mb-6 text-gray-300">
              Bringing you the finest coffee experience since 2015. We source the best beans from around the world to create memorable coffee moments.
            </p>
            <div className="flex space-x-4">
              <SocialIcon icon={<Instagram size={20} />} href="https://instagram.com" />
              <SocialIcon icon={<Facebook size={20} />} href="https://facebook.com" />
              <SocialIcon icon={<Twitter size={20} />} href="https://twitter.com" />
            </div>
          </div>
          
          {/* Quick Links */}
          <div className="md:ml-8 flex flex-col">
            <h3 className="text-lg font-semibold mb-4 font-serif">Quick Links</h3>
            <div className="flex flex-col space-y-2">
              <FooterLink to="/" label="Home" />
              <FooterLink to="/menu" label="Our Menu" />
              <FooterLink to="/about" label="About Us" />
              <FooterLink to="/contact" label="Contact" />
              <FooterLink to="/cart" label="Your Cart" />
            </div>
          </div>
          
          {/* Contact */}
          <div className="flex flex-col">
            <h3 className="text-lg font-semibold mb-4 font-serif">Contact Us</h3>
            <div className="flex flex-col space-y-4">
              <div className="flex items-start">
                <MapPin className="h-5 w-5 text-accent-gold mr-2 mt-1" />
                <p>123 Coffee Dhaka, MohamodPure, CA 94123</p>
              </div>
              <div className="flex items-center">
                <Phone className="h-5 w-5 text-accent-gold mr-2" />
                <p>016273920</p>
              </div>
              <div className="flex items-center">
                <Mail className="h-5 w-5 text-accent-gold mr-2" />
                <p>hello@brewhaven.com</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-10 pt-6 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} Abdur rahim khan store. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

interface SocialIconProps {
  icon: React.ReactNode;
  href: string;
}

const SocialIcon: React.FC<SocialIconProps> = ({ icon, href }) => {
  return (
    <a 
      href={href} 
      target="_blank" 
      rel="noopener noreferrer"
      className="bg-coffee hover:bg-accent-gold text-white rounded-full p-2 transition-colors duration-300"
    >
      {icon}
    </a>
  );
};

interface FooterLinkProps {
  to: string;
  label: string;
}

const FooterLink: React.FC<FooterLinkProps> = ({ to, label }) => {
  return (
    <Link 
      to={to}
      className="text-gray-300 hover:text-accent-gold transition-colors duration-300"
    >
      {label}
    </Link>
  );
};

export default Footer;