import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingBag, Menu, X, Coffee } from 'lucide-react';
import { useCart } from '../../contexts/CartContext';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { cartItems } = useCart();
  const location = useLocation();
  
  const totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);
  
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white shadow-md py-2' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link to="/" className="flex items-center">
          <Coffee className={`h-8 w-8 ${isScrolled ? 'text-coffee-dark' : 'text-coffee-dark'}`} />
          <span className={`ml-2 text-xl font-serif font-bold uppercase ${isScrolled ? 'text-coffee-dark' : 'text-coffee-dark'}`}>
          Abdur rahim khan store
          </span>
        </Link>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <NavLink to="/" label="Home" isScrolled={isScrolled} />
          <NavLink to="/menu" label="Menu" isScrolled={isScrolled} />
          <NavLink to="/about" label="About Us" isScrolled={isScrolled} />
          <NavLink to="/contact" label="Contact" isScrolled={isScrolled} />
          <Link to="/cart" className="relative">
            <ShoppingBag className={`h-6 w-6 ${isScrolled ? 'text-coffee-dark' : 'text-coffee-dark'}`} />
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 bg-accent-red text-coffee-dark text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                {totalItems}
              </span>
            )}
          </Link>
        </nav>
        
        {/* Mobile Navigation */}
        <div className="flex items-center md:hidden">
          <Link to="/cart" className="relative mr-4">
            <ShoppingBag className={`h-6 w-6 ${isScrolled ? 'text-coffee-dark' : 'text-coffee-dark'}`} />
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 bg-accent-red text-coffee-dark text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                {totalItems}
              </span>
            )}
          </Link>
          <button 
            onClick={() => setIsOpen(!isOpen)}
            className={`${isScrolled ? 'text-coffee-dark' : 'text-coffee-dark'}`}
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 text-coffee-dark shadow-md py-4 animate-fade-in">
          <div className="container mx-auto px-4 flex flex-col space-y-4">
            <MobileNavLink to="/" label="Home" />
            <MobileNavLink to="/menu" label="Menu" />
            <MobileNavLink to="/about" label="About Us" />
            <MobileNavLink to="/contact" label="Contact" />
          </div>
        </div>
      )}
    </header>
  );
};

interface NavLinkProps {
  to: string;
  label: string;
  isScrolled: boolean;
}

const NavLink: React.FC<NavLinkProps> = ({ to, label, isScrolled }) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  
  return (
    <Link 
      to={to} 
      className={`font-medium transition-colors duration-300 ${
        isActive 
          ? 'text-accent-red' 
          : isScrolled 
            ? 'text-coffee-dark hover:text-accent-red' 
            : 'text-coffee-dark hover:text-accent-red'
      }`}
    >
      {label}
    </Link>
  );
};

interface MobileNavLinkProps {
  to: string;
  label: string;
}

const MobileNavLink: React.FC<MobileNavLinkProps> = ({ to, label }) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  
  return (
    <Link 
      to={to} 
      className={`py-2 font-medium ${
        isActive ? 'text-accent-red' : 'text-coffee-dark hover:text-accent-red'
      }`}
    >
      {label}
    </Link>
  );
};

export default Header;