import React from 'react';
import { Minus, Plus, Trash } from 'lucide-react';
import { CartItem as CartItemType } from '../../types';
import { useCart } from '../../contexts/CartContext';

interface CartItemProps {
  item: CartItemType;
}

const CartItem: React.FC<CartItemProps> = ({ item }) => {
  const { updateQuantity, removeFromCart } = useCart();
  
  return (
    <div className="flex items-center border-b border-gray-200 py-4 animate-fade-in">
      <div className="h-20 w-20 rounded overflow-hidden">
        <img 
          src={item.image} 
          alt={item.name} 
          className="h-full w-full object-cover"
        />
      </div>
      
      <div className="flex-1 ml-4">
        <h3 className="font-medium text-coffee-dark">{item.name}</h3>
        <p className="text-sm text-gray-500 line-clamp-1">{item.description}</p>
        <div className="flex justify-between items-center mt-2">
          <p className="font-medium text-accent-red">৳{(item.price * item.quantity).toFixed(2)}</p>
          
          <div className="flex items-center">
            <button 
              onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
              className="p-1 text-gray-500 hover:text-coffee-dark transition-colors"
              aria-label="Decrease quantity"
            >
              <Minus className="w-4 h-4" />
            </button>
            
            <span className="mx-2 w-8 text-center">{item.quantity}</span>
            
            <button 
              onClick={() => updateQuantity(item.id, item.quantity + 1)}
              className="p-1 text-gray-500 hover:text-coffee-dark transition-colors"
              aria-label="Increase quantity"
            >
              <Plus className="w-4 h-4" />
            </button>
            
            <button 
              onClick={() => removeFromCart(item.id)}
              className="ml-4 p-1 text-gray-500 hover:text-accent-red transition-colors"
              aria-label="Remove item"
            >
              <Trash className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartItem;