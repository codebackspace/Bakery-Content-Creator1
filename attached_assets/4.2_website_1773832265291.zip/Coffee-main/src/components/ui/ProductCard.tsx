import React from 'react';
import { Plus } from 'lucide-react';
import Button from './Button';
import { Product } from '../../types';
import { useCart } from '../../contexts/CartContext';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  
  const handleAddToCart = () => {
    addToCart(product);
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:-translate-y-1 hover:shadow-lg animate-fade-in">
      <div className="h-48 overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-serif font-bold text-lg text-coffee-dark">{product.name}</h3>
          <span className="font-medium text-accent-red">৳{product.price.toFixed(2)}</span>
        </div>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{product.description}</p>
        
        <Button 
          onClick={handleAddToCart} 
          variant="outline" 
          size="sm" 
          fullWidth
          className="group"
        >
          <Plus className="w-4 h-4 mr-1 group-hover:scale-110 transition-transform" />
          Add to Cart
        </Button>
      </div>
      
      {product.bestseller && (
        <div className="absolute top-2 right-2 bg-accent-gold text-coffee-dark text-xs font-bold px-2 py-1 rounded">
          BESTSELLER
        </div>
      )}
    </div>
  );
};

export default ProductCard;