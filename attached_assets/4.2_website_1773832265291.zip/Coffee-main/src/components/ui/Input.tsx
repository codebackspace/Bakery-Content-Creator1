import React from 'react';

interface InputProps {
  type?: string;
  label: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  placeholder?: string;
  required?: boolean;
  error?: string;
  className?: string;
  as?: 'input' | 'textarea';
  rows?: number;
}

const Input: React.FC<InputProps> = ({
  type = 'text',
  label,
  name,
  value,
  onChange,
  placeholder = '',
  required = false,
  error,
  className = '',
  as = 'input',
  rows = 4,
}) => {
  const inputClassName = `
    w-full px-4 py-2 rounded-md border 
    ${error ? 'border-accent-red' : 'border-gray-300'} 
    focus:outline-none focus:ring-2 focus:ring-coffee-light
    transition-all duration-300
    ${className}
  `;

  return (
    <div className="mb-4">
      <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">
        {label} {required && <span className="text-accent-red">*</span>}
      </label>
      
      {as === 'textarea' ? (
        <textarea
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          required={required}
          rows={rows}
          className={inputClassName}
        />
      ) : (
        <input
          type={type}
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          required={required}
          className={inputClassName}
        />
      )}
      
      {error && (
        <p className="mt-1 text-sm text-accent-red">{error}</p>
      )}
    </div>
  );
};

export default Input;