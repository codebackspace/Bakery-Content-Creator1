import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CheckCircle } from 'lucide-react';
import Button from '../components/ui/Button';
import { useCart } from '../contexts/CartContext';

const CheckoutSuccess: React.FC = () => {
  const { cartItems } = useCart();
  const navigate = useNavigate();
  
  // Redirect to home if user navigates directly to this page without checkout
  useEffect(() => {
    if (cartItems.length > 0) {
      navigate('/cart');
    }
  }, [cartItems, navigate]);
  
  return (
    <div className="min-h-screen pt-20 pb-16 flex items-center">
      <div className="container mx-auto px-4 text-center">
        <div className="bg-white rounded-lg shadow-lg p-8 max-w-md mx-auto">
          <div className="flex justify-center mb-6">
            <CheckCircle className="h-16 w-16 text-green-500" />
          </div>
          
          <h1 className="text-3xl font-serif font-bold text-coffee-dark mb-4">
            Order Confirmed!
          </h1>
          
          <p className="text-gray-600 mb-6">
            Thank you for your order. We've received your order and will begin preparing it right away.
            You'll receive a confirmation email shortly.
          </p>
          
          <div className="py-4 border-t border-b border-gray-200 mb-6">
            <div className="text-left">
              <p className="font-medium text-coffee-dark">Order #BD65GH78</p>
              <p className="text-gray-500">Estimated delivery: 30-45 minutes</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <Link to="/">
              <Button variant="primary" fullWidth>
                Return to Home
              </Button>
            </Link>
            
            <Link to="/menu">
              <Button variant="outline" fullWidth>
                Order Again
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutSuccess;