import React from 'react';
import { ArrowRight, Coffee, Award, Leaf } from 'lucide-react';
import { Link } from 'react-router-dom';
import Button from '../components/ui/Button';

const About: React.FC = () => {
  return (
    <div className="min-h-screen pt-20 pb-16">
      {/* Header */}
      <div className="bg-coffee-dark text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-4xl font-serif font-bold mb-4">Our Story</h1>
          <p className="max-w-2xl mx-auto">
            Learn about our journey, our passion for coffee, and our commitment to quality.
          </p>
        </div>
      </div>
      
      {/* Our Story */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <img 
                src="https://images.pexels.com/photos/1002219/pexels-photo-1002219.jpeg" 
                alt="Abdur rahim khan store Coffee Shop" 
                className="rounded-lg shadow-lg w-full h-auto object-cover"
              />
            </div>
            
            <div className="md:w-1/2">
              <h2 className="text-3xl font-serif font-bold text-coffee-dark mb-4">How We Started</h2>
              <p className="text-gray-700 mb-4">
              Abdur rahim khan store began in 2015 with a simple idea: create a warm, welcoming space where people could enjoy exceptional coffee. Our founder, Sarah Chen, was inspired by her travels through the coffee regions of Ethiopia, Colombia, and Indonesia, where she witnessed firsthand the artistry and dedication of coffee farmers.
              </p>
              <p className="text-gray-700 mb-6">
                What started as a small corner café has grown into a beloved community hub, where coffee enthusiasts gather to savor meticulously crafted beverages and enjoy moments of connection. Our commitment to quality, sustainability, and the perfect cup remains unwavering.
              </p>
              <Link to="/contact">
                <Button variant="primary">
                  Get in Touch <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Our Values */}
      <section className="py-16 bg-cream">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-serif font-bold text-coffee-dark mb-4">Our Values</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              The principles that guide everything we do at Abdur rahim khan store.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <ValueCard 
              icon={<Coffee className="h-12 w-12 text-accent-gold" />}
              title="Quality Above All"
              description="We source only the finest beans and ingredients, and train our baristas in the art of perfect extraction and preparation."
            />
            <ValueCard 
              icon={<Leaf className="h-12 w-12 text-accent-gold" />}
              title="Sustainability"
              description="We partner with ethical farms, use eco-friendly packaging, and continuously work to reduce our environmental footprint."
            />
            <ValueCard 
              icon={<Award className="h-12 w-12 text-accent-gold" />}
              title="Community"
              description="Our coffee shop is more than a business – it's a gathering place where friendships form and ideas flourish."
            />
          </div>
        </div>
      </section>
      
      {/* Our Coffee */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row-reverse items-center gap-8">
            <div className="md:w-1/2">
              <img 
                src="https://images.pexels.com/photos/894695/pexels-photo-894695.jpeg" 
                alt="Coffee Beans" 
                className="rounded-lg shadow-lg w-full h-auto object-cover"
              />
            </div>
            
            <div className="md:w-1/2">
              <h2 className="text-3xl font-serif font-bold text-coffee-dark mb-4">Our Coffee</h2>
              <p className="text-gray-700 mb-4">
                We take our coffee seriously. Our beans are sourced from small, sustainable farms in Ethiopia, Colombia, Guatemala, and other renowned coffee regions. We work directly with farmers whenever possible to ensure fair compensation and maintain relationships that benefit everyone in the supply chain.
              </p>
              <p className="text-gray-700 mb-4">
                Our master roaster carefully develops each roast profile to highlight the unique characteristics of every bean variety. Whether you prefer bright, fruity notes or rich, chocolatey undertones, our diverse selection offers something for every palate.
              </p>
              <p className="text-gray-700 mb-6">
                We rotate our offerings seasonally to ensure freshness and to showcase the best harvests available throughout the year.
              </p>
              <Link to="/menu">
                <Button variant="primary">
                  Explore Our Menu <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Team Section */}
      <section className="py-16 bg-coffee-dark text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-serif font-bold mb-4">Meet Our Team</h2>
            <p className="max-w-2xl mx-auto text-gray-300">
              The talented individuals who make the magic happen every day.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <TeamMember
              image="https://images.pexels.com/photos/3771118/pexels-photo-3771118.jpeg"
              name="Sarah Chen"
              title="Founder & Head Barista"
              bio="Coffee enthusiast with over 10 years of experience. Sarah has traveled to over 15 countries studying coffee cultivation and preparation techniques."
            />
            <TeamMember
              image="https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg"
              name="Marcus Johnson"
              title="Master Roaster"
              bio="With a background in chemistry, Marcus brings scientific precision to our roasting process, creating perfectly balanced flavor profiles."
            />
            <TeamMember
              image="https://images.pexels.com/photos/6205509/pexels-photo-6205509.jpeg"
              name="Elena Rodriguez"
              title="Head Chef"
              bio="Pastry expert who trained in Paris. Elena creates our delicious pastries and snacks that perfectly complement our coffee offerings."
            />
          </div>
        </div>
      </section>
    </div>
  );
};

interface ValueCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const ValueCard: React.FC<ValueCardProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 text-center transition-transform hover:-translate-y-1 hover:shadow-lg">
      <div className="flex justify-center mb-4">{icon}</div>
      <h3 className="text-xl font-serif font-bold text-coffee-dark mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

interface TeamMemberProps {
  image: string;
  name: string;
  title: string;
  bio: string;
}

const TeamMember: React.FC<TeamMemberProps> = ({ image, name, title, bio }) => {
  return (
    <div className="bg-coffee rounded-lg overflow-hidden shadow-md transition-transform hover:-translate-y-1 hover:shadow-lg">
      <img 
        src={image} 
        alt={name} 
        className="w-full h-64 object-cover"
      />
      <div className="p-6">
        <h3 className="text-xl font-serif font-bold text-white mb-1">{name}</h3>
        <p className="text-accent-gold font-medium mb-3">{title}</p>
        <p className="text-gray-300">{bio}</p>
      </div>
    </div>
  );
};

export default About;