import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { ContactForm } from '../types';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState<ContactForm>({
    name: '',
    email: '',
    message: '',
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setFormData({ name: '', email: '', message: '' });
      
      // Reset success message after 5 seconds
      setTimeout(() => {
        setIsSubmitted(false);
      }, 5000);
    }, 1500);
  };

  return (
    <div className="min-h-screen pt-20 pb-16">
      {/* Header */}
      <div className="bg-coffee-dark text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-4xl font-serif font-bold mb-4">Contact Us</h1>
          <p className="max-w-2xl mx-auto">
            We'd love to hear from you. Get in touch with our team for any questions, feedback, or inquiries.
          </p>
        </div>
      </div>
      
      {/* Contact Information */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-2xl font-serif font-bold text-coffee-dark mb-6">Get In Touch</h2>
              
              <div className="space-y-6">
                <ContactInfo 
                  icon={<MapPin className="h-6 w-6 text-accent-gold" />}
                  title="Our Location"
                  content="123 Coffee Street, Brewville, CA 94123"
                />
                <ContactInfo 
                  icon={<Phone className="h-6 w-6 text-accent-gold" />}
                  title="Phone Number"
                  content="016273920"
                />
                <ContactInfo 
                  icon={<Mail className="h-6 w-6 text-accent-gold" />}
                  title="Email Address"
                  content="hello@brewhaven.com"
                />
                <ContactInfo 
                  icon={<Clock className="h-6 w-6 text-accent-gold" />}
                  title="Opening Hours"
                  content={
                    <div>
                      <p>Monday - Friday: 7:00 AM - 8:00 PM</p>
                      <p>Saturday - Sunday: 8:00 AM - 6:00 PM</p>
                    </div>
                  }
                />
              </div>
              
              <div className="mt-8">
                <h3 className="text-xl font-serif font-bold text-coffee-dark mb-4">Follow Us</h3>
                <div className="flex space-x-4">
                  <SocialLink href="https://instagram.com" label="Instagram" />
                  <SocialLink href="https://facebook.com" label="Facebook" />
                  <SocialLink href="https://twitter.com" label="Twitter" />
                </div>
              </div>
            </div>
            
            <div>
              <h2 className="text-2xl font-serif font-bold text-coffee-dark mb-6">Send Us a Message</h2>
              
              {isSubmitted ? (
                <div className="bg-green-100 border border-green-200 text-green-800 rounded-lg p-4 animate-fade-in">
                  <p className="font-medium">Thank you for your message!</p>
                  <p>We'll get back to you as soon as possible.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <Input
                    label="Your Name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="John Doe"
                    required
                  />
                  
                  <Input
                    type="email"
                    label="Your Email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="john@example.com"
                    required
                  />
                  
                  <Input
                    as="textarea"
                    label="Your Message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="How can we help you?"
                    required
                    rows={5}
                  />
                  
                  <Button 
                    type="submit" 
                    variant="primary" 
                    disabled={isSubmitting}
                    className="w-full md:w-auto"
                  >
                    {isSubmitting ? 'Sending...' : (
                      <>
                        Send Message <Send className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
      
      {/* Map Section */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="bg-gray-200 rounded-lg overflow-hidden h-80 shadow-md">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d100940.14245968247!2d-122.43759999999999!3d37.75769999999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80859a6d00690021%3A0x4a501367f076adff!2sSan%20Francisco%2C%20CA!5e0!3m2!1sen!2sus!4v1625103555!5m2!1sen!2sus"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Abdur rahim khan store Coffee Shop Location"
            ></iframe>
          </div>
        </div>
      </section>
    </div>
  );
};

interface ContactInfoProps {
  icon: React.ReactNode;
  title: string;
  content: React.ReactNode;
}

const ContactInfo: React.FC<ContactInfoProps> = ({ icon, title, content }) => {
  return (
    <div className="flex">
      <div className="mt-1">{icon}</div>
      <div className="ml-4">
        <h3 className="font-medium text-coffee-dark">{title}</h3>
        <div className="text-gray-600">{content}</div>
      </div>
    </div>
  );
};

interface SocialLinkProps {
  href: string;
  label: string;
}

const SocialLink: React.FC<SocialLinkProps> = ({ href, label }) => {
  return (
    <a 
      href={href} 
      target="_blank" 
      rel="noopener noreferrer"
      className="bg-gray-100 hover:bg-accent-gold hover:text-white text-coffee-dark px-4 py-2 rounded transition-colors duration-300"
    >
      {label}
    </a>
  );
};

export default Contact;