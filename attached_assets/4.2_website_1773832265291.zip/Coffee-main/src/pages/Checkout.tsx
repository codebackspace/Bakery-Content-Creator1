import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, DollarSign, Smartphone, ShieldCheck } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { useCart } from '../contexts/CartContext';
import { DeliveryInfo, PaymentMethod } from '../types';
import { paymentMethods } from '../utils/data';

const Checkout: React.FC = () => {
  const { cartItems, totalPrice, clearCart } = useCart();
  const navigate = useNavigate();
  
  const [deliveryInfo, setDeliveryInfo] = useState<DeliveryInfo>({
    name: '',
    address: '',
    phone: '',
    email: '',
  });
  
  const [selectedPayment, setSelectedPayment] = useState<string>(paymentMethods[0].id);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const tax = totalPrice * 0.1; // 10% tax
  const total = totalPrice + tax;
  
  useEffect(() => {
    // Redirect to cart if cart is empty
    if (cartItems.length === 0) {
      navigate('/cart');
    }
  }, [cartItems, navigate]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setDeliveryInfo(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };
  
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!deliveryInfo.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!deliveryInfo.address.trim()) {
      newErrors.address = 'Address is required';
    }
    
    if (!deliveryInfo.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    }
    
    if (!deliveryInfo.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(deliveryInfo.email)) {
      newErrors.email = 'Email is invalid';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate processing order
    setTimeout(() => {
      clearCart();
      navigate('/checkout/success');
    }, 2000);
  };

  return (
    <div className="min-h-screen pt-20 pb-16">
      {/* Header */}
      <div className="bg-coffee-dark text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-4xl font-serif font-bold mb-4">Checkout</h1>
          <p className="max-w-2xl mx-auto">
            Complete your order by providing your delivery and payment information.
          </p>
        </div>
      </div>
      
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Checkout Form */}
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-serif font-bold text-coffee-dark mb-6">Delivery Information</h2>
              
              <form onSubmit={handleSubmit}>
                <div className="bg-white rounded-lg shadow-md p-6 mb-8">
                  <Input
                    label="Full Name"
                    name="name"
                    value={deliveryInfo.name}
                    onChange={handleChange}
                    required
                    error={errors.name}
                  />
                  
                  <Input
                    label="Delivery Address"
                    name="address"
                    value={deliveryInfo.address}
                    onChange={handleChange}
                    required
                    error={errors.address}
                  />
                  
                  <Input
                    type="tel"
                    label="Phone Number"
                    name="phone"
                    value={deliveryInfo.phone}
                    onChange={handleChange}
                    required
                    error={errors.phone}
                  />
                  
                  <Input
                    type="email"
                    label="Email Address"
                    name="email"
                    value={deliveryInfo.email}
                    onChange={handleChange}
                    required
                    error={errors.email}
                  />
                </div>
                
                <h2 className="text-2xl font-serif font-bold text-coffee-dark mb-6">Payment Method</h2>
                
                <div className="bg-white rounded-lg shadow-md p-6 mb-8">
                  <div className="space-y-4">
                    {paymentMethods.map(method => (
                      <PaymentOption
                        key={method.id}
                        method={method}
                        selected={selectedPayment === method.id}
                        onSelect={() => setSelectedPayment(method.id)}
                      />
                    ))}
                  </div>
                </div>
                
                <div className="flex justify-end mt-6">
                  <Button
                    type="submit"
                    variant="primary"
                    size="lg"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? 'Processing...' : 'Complete Order'}
                  </Button>
                </div>
              </form>
            </div>
            
            {/* Order Summary */}
            <div>
              <h2 className="text-2xl font-serif font-bold text-coffee-dark mb-6">Order Summary</h2>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="max-h-60 overflow-y-auto mb-4">
                  {cartItems.map(item => (
                    <div key={item.id} className="flex justify-between items-center py-2 border-b border-gray-100">
                      <div className="flex items-center">
                        <span className="font-medium">{item.quantity} x</span>
                        <span className="ml-2">{item.name}</span>
                      </div>
                      <span>৳{(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
                
                <div className="space-y-2 pt-2">
                  <div className="flex justify-between text-gray-600">
                    <span>Subtotal</span>
                    <span>৳{totalPrice.toFixed(2)}</span>
                  </div>
                  
                  <div className="flex justify-between text-gray-600">
                    <span>Tax (10%)</span>
                    <span>৳{tax.toFixed(2)}</span>
                  </div>
                  
                  <div className="border-t border-gray-200 pt-2 mt-2 flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span>৳{total.toFixed(2)}</span>
                  </div>
                </div>
                
                <div className="mt-6 pt-4 border-t border-gray-200 flex items-center justify-center text-sm text-gray-500">
                  <ShieldCheck className="h-4 w-4 mr-2 text-green-500" />
                  <span>Secure checkout powered by Stripe</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

interface PaymentOptionProps {
  method: PaymentMethod;
  selected: boolean;
  onSelect: () => void;
}

const PaymentOption: React.FC<PaymentOptionProps> = ({ method, selected, onSelect }) => {
  const getIcon = (id: string) => {
    switch (id) {
      case 'credit':
        return <CreditCard className="h-5 w-5" />;
      case 'cash':
        return <DollarSign className="h-5 w-5" />;
      case 'mobile':
        return <Smartphone className="h-5 w-5" />;
      default:
        return <CreditCard className="h-5 w-5" />;
    }
  };
  
  return (
    <div
      onClick={onSelect}
      className={`
        border rounded-lg p-4 cursor-pointer transition-all duration-300
        ${selected 
          ? 'border-accent-gold bg-cream' 
          : 'border-gray-200 hover:border-gray-300'
        }
      `}
    >
      <div className="flex items-center">
        <div className="flex-shrink-0 mr-4">
          <div className={`
            h-6 w-6 rounded-full border flex items-center justify-center
            ${selected ? 'border-accent-gold' : 'border-gray-300'}
          `}>
            {selected && (
              <div className="h-3 w-3 rounded-full bg-accent-gold"></div>
            )}
          </div>
        </div>
        
        <div className="flex items-center">
          {getIcon(method.id)}
          <span className="ml-2 font-medium">{method.name}</span>
        </div>
      </div>
    </div>
  );
};

export default Checkout;