import React from 'react';
import { Link } from 'react-router-dom';
import { Coffee, CupSoda, Utensils } from 'lucide-react';
import Button from '../components/ui/Button';
import ProductCard from '../components/ui/ProductCard';
import { getBestSellers } from '../utils/data';

const Home: React.FC = () => {
  const bestSellers = getBestSellers();
  
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section 
        className="relative h-screen bg-center bg-cover"
        style={{ 
          backgroundImage: 'url(https://images.pexels.com/photos/683039/pexels-photo-683039.jpeg)'
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-60"></div>
        <div className="relative container mx-auto px-4 h-full flex flex-col justify-center">
          <div className="max-w-xl animate-slide-up">
            <h1 className="text-white text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-4">
              Freshly Brewed Coffee Everyday
            </h1>
            <p className="text-white text-lg mb-8">
              Experience the rich aroma and exquisite taste of our premium coffee, sourced from the finest beans around the world.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/menu">
                <Button variant="primary" size="lg">
                  View Menu
                </Button>
              </Link>
              <Link to="/about">
                <Button variant="outline" size="lg" className="text-white border-white hover:bg-white hover:text-coffee-dark">
                  Our Story
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Categories Section */}
      <section className="py-16 bg-cream">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-serif font-bold text-coffee-dark mb-2">What We Offer</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Discover our wide selection of handcrafted beverages and delicious treats made with the finest ingredients.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <CategoryCard 
              icon={<Coffee className="h-12 w-12 text-accent-gold" />}
              title="Premium Coffee"
              description="From classic espresso to specialty lattes, our coffee is brewed to perfection."
              link="/menu?category=coffee"
            />
            <CategoryCard 
              icon={<CupSoda className="h-12 w-12 text-accent-gold" />}
              title="Refreshing Teas"
              description="Enjoy our selection of loose-leaf teas, herbal infusions, and tea lattes."
              link="/menu?category=tea"
            />
            <CategoryCard 
              icon={<Utensils className="h-12 w-12 text-accent-gold" />}
              title="Delicious Treats"
              description="Pair your beverage with our freshly baked pastries and savory snacks."
              link="/menu?category=pastry"
            />
          </div>
        </div>
      </section>
      
      {/* Best Sellers Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-serif font-bold text-coffee-dark mb-2">Our Best Sellers</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Customer favorites that keep them coming back for more.</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {bestSellers.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          
          <div className="text-center mt-10">
            <Link to="/menu">
              <Button variant="secondary">
                View Full Menu
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-coffee bg-opacity-10">
        <div className="container mx-auto px-4">
          <div className="bg-coffee-dark rounded-lg p-8 md:p-12 shadow-xl">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-serif font-bold text-white mb-4">Ready for a Coffee Break?</h2>
              <p className="text-gray-300 mb-8">
                Visit our coffee shop today or order online for pickup or delivery. We're ready to serve you the perfect cup!
              </p>
              <Link to="/menu">
                <Button variant="secondary" size="lg">
                  Order Now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

interface CategoryCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  link: string;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ icon, title, description, link }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 text-center transition-transform hover:-translate-y-1 hover:shadow-lg">
      <div className="flex justify-center mb-4">{icon}</div>
      <h3 className="text-xl font-serif font-bold text-coffee-dark mb-2">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      <Link 
        to={link}
        className="text-coffee inline-block font-medium hover:text-coffee-dark transition-colors"
      >
        Explore &rarr;
      </Link>
    </div>
  );
};

export default Home;