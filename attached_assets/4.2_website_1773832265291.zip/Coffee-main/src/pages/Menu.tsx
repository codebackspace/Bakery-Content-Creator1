import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Coffee, CupSoda, Utensils, ShoppingBag } from 'lucide-react';
import ProductCard from '../components/ui/ProductCard';
import { getProductsByCategory } from '../utils/data';
import { Product } from '../types';

const Menu: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialCategory = searchParams.get('category') || 'all';
  
  const [activeCategory, setActiveCategory] = useState(initialCategory);
  const [products, setProducts] = useState<Product[]>([]);
  
  useEffect(() => {
    setProducts(getProductsByCategory(activeCategory));
  }, [activeCategory]);
  
  useEffect(() => {
    const category = searchParams.get('category');
    if (category) {
      setActiveCategory(category);
    }
  }, [searchParams]);
  
  const handleCategoryChange = (category: string) => {
    setActiveCategory(category);
    setSearchParams({ category });
  };

  return (
    <div className="min-h-screen pt-20 pb-16">
      {/* Header */}
      <div className="bg-coffee-dark text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-4xl font-serif font-bold mb-4">Our Menu</h1>
          <p className="max-w-2xl mx-auto">
            Explore our wide selection of handcrafted beverages and delicious treats made with the finest ingredients.
          </p>
        </div>
      </div>
      
      {/* Category Filters */}
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-wrap justify-center gap-4 mb-8">
          <CategoryButton 
            isActive={activeCategory === 'all'}
            onClick={() => handleCategoryChange('all')}
            icon={<ShoppingBag className="h-5 w-5" />}
            label="All Items"
          />
          <CategoryButton 
            isActive={activeCategory === 'coffee'}
            onClick={() => handleCategoryChange('coffee')}
            icon={<Coffee className="h-5 w-5" />}
            label="Coffee"
          />
          <CategoryButton 
            isActive={activeCategory === 'tea'}
            onClick={() => handleCategoryChange('tea')}
            icon={<CupSoda className="h-5 w-5" />}
            label="Tea"
          />
          <CategoryButton 
            isActive={activeCategory === 'pastry'}
            onClick={() => handleCategoryChange('pastry')}
            icon={<Utensils className="h-5 w-5" />}
            label="Pastries"
          />
          <CategoryButton 
            isActive={activeCategory === 'snack'}
            onClick={() => handleCategoryChange('snack')}
            icon={<Utensils className="h-5 w-5" />}
            label="Snacks"
          />
        </div>
        
        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {products.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
        
        {products.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No products found in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
};

interface CategoryButtonProps {
  isActive: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}

const CategoryButton: React.FC<CategoryButtonProps> = ({ isActive, onClick, icon, label }) => {
  return (
    <button
      onClick={onClick}
      className={`
        flex items-center px-4 py-2 rounded-full transition-all duration-300
        ${
          isActive
            ? 'bg-coffee-dark text-white shadow-md'
            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
        }
      `}
    >
      <span className="mr-2">{icon}</span>
      <span>{label}</span>
    </button>
  );
};

export default Menu;