import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, AlertCircle, ArrowRight } from 'lucide-react';
import CartItem from '../components/cart/CartItem';
import Button from '../components/ui/Button';
import { useCart } from '../contexts/CartContext';

const Cart: React.FC = () => {
  const { cartItems, totalPrice, clearCart } = useCart();
  
  const tax = totalPrice * 0.1; // 10% tax
  const total = totalPrice + tax;

  return (
    <div className="min-h-screen pt-20 pb-16">
      {/* Header */}
      <div className="bg-coffee-dark text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-4xl font-serif font-bold mb-4">Your Cart</h1>
          <p className="max-w-2xl mx-auto">
            Review your items before proceeding to checkout.
          </p>
        </div>
      </div>
      
      <section className="py-16">
        <div className="container mx-auto px-4">
          {cartItems.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2">
                <h2 className="text-2xl font-serif font-bold text-coffee-dark mb-6">Items</h2>
                
                <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
                  <div className="space-y-1">
                    {cartItems.map(item => (
                      <CartItem key={item.id} item={item} />
                    ))}
                  </div>
                  
                  <div className="mt-6 pt-4 border-t border-gray-200">
                    <button
                      onClick={clearCart}
                      className="text-accent-red font-medium hover:underline"
                    >
                      Clear Cart
                    </button>
                  </div>
                </div>
              </div>
              
              {/* Order Summary */}
              <div>
                <h2 className="text-2xl font-serif font-bold text-coffee-dark mb-6">Order Summary</h2>
                
                <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
                  <div className="space-y-4">
                    <div className="flex justify-between text-gray-600">
                      <span>Subtotal</span>
                      <span>৳{totalPrice.toFixed(2)}</span>
                    </div>
                    
                    <div className="flex justify-between text-gray-600">
                      <span>Tax (10%)</span>
                      <span>৳{tax.toFixed(2)}</span>
                    </div>
                    
                    <div className="border-t border-gray-200 pt-4 flex justify-between font-bold text-lg">
                      <span>Total</span>
                      <span>৳{total.toFixed(2)}</span>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <Link to="/checkout">
                      <Button variant="primary" fullWidth>
                        Proceed to Checkout <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                  
                  <div className="mt-4 text-center text-sm text-gray-500">
                    <p>Secure payment powered by Stripe</p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="inline-flex items-center justify-center w-24 h-24 bg-gray-100 rounded-full mb-6">
                <ShoppingCart className="h-12 w-12 text-gray-400" />
              </div>
              
              <h2 className="text-2xl font-serif font-bold text-coffee-dark mb-2">Your cart is empty</h2>
              <p className="text-gray-600 mb-8">Looks like you haven't added any items to your cart yet.</p>
              
              <Link to="/menu">
                <Button variant="primary">
                  Browse Our Menu
                </Button>
              </Link>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Cart;