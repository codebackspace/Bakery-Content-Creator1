import { Product, PaymentMethod } from '../types';

export const products: Product[] = [
  {
    id: 1,
    name: 'Classic Cappuccino',
    description: 'Our signature cappuccino with a perfect balance of espresso, steamed milk, and foam',
    price: 54.99,
    image: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg',
    category: 'coffee',
    bestseller: true
  },
  {
    id: 2,
    name: 'Caramel Latte',
    description: 'Smooth espresso with steamed milk and rich caramel syrup',
    price: 75.49,
    image: 'https://images.pexels.com/photos/3879495/pexels-photo-3879495.jpeg',
    category: 'coffee',
    bestseller: true
  },
  {
    id: 3,
    name: 'Mocha Frappuccino',
    description: 'Blended coffee with chocolate, milk, and ice topped with whipped cream',
    price: 65.99,
    image: 'https://images.pexels.com/photos/4790062/pexels-photo-4790062.jpeg',
    category: 'coffee'
  },
  {
    id: 4,
    name: 'Americano',
    description: 'Espresso diluted with hot water for a rich, bold flavor',
    price: 43.99,
    image: 'https://images.pexels.com/photos/6207297/pexels-photo-6207297.jpeg',
    category: 'coffee'
  },
  {
    id: 5,
    name: 'Green Tea',
    description: 'Premium Japanese green tea with delicate flavor',
    price: 63.49,
    image: 'https://images.pexels.com/photos/1410148/pexels-photo-1410148.jpeg',
    category: 'tea'
  },
  {
    id: 6,
    name: 'Chocolate Croissant',
    description: 'Buttery, flaky croissant filled with rich chocolate',
    price: 83.99,
    image: 'https://images.pexels.com/photos/2135/food-france-morning-breakfast.jpg',
    category: 'pastry',
    bestseller: true
  },
  {
    id: 7,
    name: 'Blueberry Muffin',
    description: 'Moist muffin packed with fresh blueberries',
    price: 83.49,
    image: 'https://images.pexels.com/photos/1657343/pexels-photo-1657343.jpeg',
    category: 'pastry'
  },
  {
    id: 8,
    name: 'Avocado Toast',
    description: 'Multigrain toast topped with fresh avocado, cherry tomatoes, and microgreens',
    price: 96.99,
    image: 'https://images.pexels.com/photos/1351238/pexels-photo-1351238.jpeg',
    category: 'snack',
    bestseller: true
  },
  {
    id: 9,
    name: 'Chai Latte',
    description: 'Spiced black tea concentrate with steamed milk',
    price: 94.49,
    image: 'https://images.pexels.com/photos/5946642/pexels-photo-5946642.jpeg',
    category: 'tea'
  },
  {
    id: 10,
    name: 'Cinnamon Roll',
    description: 'Freshly baked cinnamon roll with cream cheese frosting',
    price: 44.29,
    image: 'https://images.pexels.com/photos/267308/pexels-photo-267308.jpeg',
    category: 'pastry'
  },
  {
    id: 11,
    name: 'Turkey & Cheese Sandwich',
    description: 'Sliced turkey breast with provolone cheese, lettuce, and tomato on sourdough bread',
    price: 47.99,
    image: 'https://images.pexels.com/photos/1647163/pexels-photo-1647163.jpeg',
    category: 'snack'
  },
  {
    id: 112,
    name: 'Earl Grey Tea',
    description: 'Black tea flavored with oil of bergamot',
    price: 3.49,
    image: 'https://images.pexels.com/photos/1417945/pexels-photo-1417945.jpeg',
    category: 'tea'
  }
];

export const paymentMethods: PaymentMethod[] = [
  { id: 'cash', name: 'Cash on Delivery' },
  { id: 'credit', name: 'Credit Card' },
  { id: 'mobile', name: 'Mobile Payment' }
];

export const getBestSellers = (): Product[] => {
  return products.filter(product => product.bestseller);
};

export const getProductsByCategory = (category: string): Product[] => {
  if (category === 'all') return products;
  return products.filter(product => product.category === category);
};

export const getProductById = (id: number): Product | undefined => {
  return products.find(product => product.id === id);
};